# Publishing to npm

This repository is prepared as an npm package.

## Option A: publish as an unscoped package (default)
Package name is set to **`kineticliquid-sdk`** in `package.json`.

1) Ensure the name is available on npm:

```bash
npm view kineticliquid-sdk
```

2) Build locally:

```bash
npm install
npm run build
npm test
```

3) Publish:

```bash
npm login
npm publish --access public
```

## Option B: publish as a scoped package (recommended)
If you want `@kineticliquid/sdk`:

1) Edit `package.json`:

```json
{"name": "@kineticliquid/sdk"}
```

2) Publish (scoped packages are public only with `--access public`):

```bash
npm publish --access public
```

## Versioning

Use semver:

```bash
npm version patch
npm version minor
npm version major
```

Then publish.
