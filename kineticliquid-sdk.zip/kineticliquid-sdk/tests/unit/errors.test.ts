import { describe, expect, it } from 'vitest';
import { asKineticLiquidError, ExecutionFailureError, InvalidVaultStateError } from '../../src/types/Errors.js';

describe('Errors', () => {
  it('preserves KineticLiquidError instances', () => {
    const e = new InvalidVaultStateError('vault', 'bad');
    expect(asKineticLiquidError(e)).toBe(e);
  });

  it('wraps native Error deterministically', () => {
    const native = new Error('boom');
    const wrapped = asKineticLiquidError(native);
    expect(wrapped).toBeInstanceOf(ExecutionFailureError);
    expect(wrapped.message).toContain('boom');
  });

  it('wraps unknown values deterministically', () => {
    const wrapped = asKineticLiquidError('x');
    expect(wrapped).toBeInstanceOf(ExecutionFailureError);
    expect(wrapped.message).toBe('Unknown error');
  });
});
